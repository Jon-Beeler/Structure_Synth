#include "PrimitiveClass.h"

namespace StructureSynth {
	namespace Model {	
		
	}
}

