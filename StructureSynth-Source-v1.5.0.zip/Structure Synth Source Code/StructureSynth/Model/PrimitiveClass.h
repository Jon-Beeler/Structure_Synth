#pragma once

#include <QString>

namespace StructureSynth {
	namespace Model {	

		/// Every PrimitiveRule can be assigned a class.
		
	}
}

